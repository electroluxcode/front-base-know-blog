
# https://developer.android.com/studio/command-line/adb?hl=zh-cn#notlisted

# width=1080

# height=2340
# adb shell wm size 获取屏幕宽高   
#  172.18.89.179 
# adb connect 172.18.89.179:6666


echo "请输入你想沟通的人数"
read n
count=1
while ((count<=n))
do  
    # 点击沟通列表
    adb shell input tap 460 450
    sleep 2
    # 点击最下面的立即沟通
    adb shell input tap 530 2200 
    sleep 2
    adb shell input keyevent BACK
    sleep 2
    adb shell input keyevent BACK
    sleep 2
    adb shell input swipe 960 950 960 600
    echo "当前沟通了: $count 人"
    ((count++))
    sleep 2
done



# 点击列表的一项
# adb shell input tap 460 450
# sleep 2
# adb shell input tap 530 2200 
# sleep 2
# adb shell input keyevent BACK
# sleep 2
# adb shell input keyevent BACK
# sleep 2
# adb shell input swipe 960 950 960 600


# 指定设备控制：
# adb devices    // 172.18.89.179:6666      device
# adb -s 172.18.89.179:6666 shell input keyevent BACK

# 输入
# adb shell input text test123456

# 常按
# adb shell input swipe 300 300 300 300 500